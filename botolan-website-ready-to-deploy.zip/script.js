(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const notice = $('#notice');
  const mapPanel = $('.map-panel');
  const mapImage = $('#mapImage');
  const markerLayer = $('#mapMarkerLayer');
  let zoom = 1, panX = 0, panY = 0, noticeTimer;

  const places = [
    { name:'Poblacion', category:'Barangays', x:54.1, y:43.5, description:'The central area of Botolan and a useful starting point for exploring the municipality.' },
    { name:'Barangay San Isidro', category:'Barangays', x:55.4, y:12.5, description:'A barangay in the northern part of the illustrated Botolan map.' },
    { name:'Barangay San Felipe', category:'Barangays', x:39.8, y:25.3, description:'A barangay shown in the northwestern area of the illustrated map.' },
    { name:'Barangay Cabangan', category:'Barangays', x:31.5, y:49.5, description:'A barangay shown in the western-central area of the illustrated map.' },
    { name:'Barangay Arew', category:'Barangays', x:27.0, y:66.2, description:'A barangay shown in the southwestern area of the illustrated map.' },
    { name:'Barangay San Narciso', category:'Barangays', x:55.3, y:58.5, description:'A barangay shown in the southeastern-central area of the illustrated map.' },
    { name:'Cabangan Beach', category:'Beaches', x:19, y:79, description:'A beach destination featured in the Botolan tourism reference design.' , image:'assets/cabangan-beach.png'},
    { name:'San Felipe Falls', category:'Rivers & Falls', x:49, y:83, description:'A waterfall attraction featured in the Botolan tourism reference design.', image:'assets/san-felipe-falls.png'},
    { name:'St. Joseph Parish Church', category:'Tourist Spots', x:64, y:45, description:'A church attraction featured in the Botolan tourism reference design.', image:'assets/parish-church.png'},
    { name:'Botolan Municipal Hall', category:'Municipal Hall', x:54, y:43, description:'Municipal government offices and a point of reference in the town.', image:'assets/municipal-hall.png'},
    { name:'Mountains of Botolan', category:'Mountains', x:73, y:22, description:'Mountain landscapes form part of the natural scenery around Botolan.'}
  ];

  function showNotice(message) {
    notice.textContent = message;
    notice.classList.add('show');
    clearTimeout(noticeTimer);
    noticeTimer = setTimeout(() => notice.classList.remove('show'), 2800);
  }
  function showMapToast(message) {
    const toast = $('#mapToast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(noticeTimer);
    noticeTimer = setTimeout(() => toast.classList.remove('show'), 2100);
  }
  function renderMarkers() {
    if (!markerLayer) return;
    markerLayer.innerHTML = '';
    places.forEach((place) => {
      const marker = document.createElement('button');
      marker.type = 'button';
      marker.className = 'map-hotspot';
      marker.style.left = `${place.x}%`;
      marker.style.top = `${place.y}%`;
      marker.dataset.place = place.name;
      marker.dataset.category = place.category;
      marker.setAttribute('aria-label', `Show ${place.name}`);
      marker.title = place.name;
      if (place.name === 'Poblacion') marker.innerHTML = '<span class="marker-label">Poblacion</span>';
      marker.addEventListener('click', () => openPlace(place));
      markerLayer.appendChild(marker);
    });
    applyMapTransform();
  }
  function applyMapTransform() {
    const transform = `translate(${panX}px, ${panY}px) scale(${zoom})`;
    mapImage.style.transform = transform;
    if (markerLayer) markerLayer.style.transform = transform;
  }
  function setZoom(next) {
    zoom = Math.max(1, Math.min(2.2, next));
    applyMapTransform();
    showMapToast(`Map zoom: ${Math.round(zoom * 100)}%`);
  }
  function openModal(title, body, image) {
    const modal = $('#infoModal');
    $('#modalTitle').textContent = title;
    $('#modalBody').innerHTML = '';
    if (image) {
      const img = document.createElement('img');
      img.src = image; img.alt = title; $('#modalBody').appendChild(img);
    }
    const paragraph = document.createElement('p');
    paragraph.textContent = body;
    $('#modalBody').appendChild(paragraph);
    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    $('#modalClose').focus();
  }
  function closeModal() {
    const modal = $('#infoModal');
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
  }
  function openPlace(place) {
    $$('.map-hotspot').forEach(marker => marker.classList.toggle('active', marker.dataset.place === place.name));
    openModal(place.name, place.description, place.image);
  }
  function selectCategory(category) {
    $$('.category-item').forEach(button => {
      const selected = button.dataset.category === category;
      button.classList.toggle('selected', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
    $$('.map-hotspot').forEach(marker => {
      marker.classList.toggle('filtered-out', marker.dataset.category !== category);
      marker.classList.remove('active');
    });
    showMapToast(`Showing ${category} on the map`);
    $('#map').scrollIntoView({ behavior:'smooth', block:'center' });
  }

  // Mobile navigation and section links
  $('#menuToggle').addEventListener('click', () => {
    const nav = $('#mainNav');
    const isOpen = nav.classList.toggle('open');
    $('#menuToggle').setAttribute('aria-expanded', String(isOpen));
    $('#menuToggle').setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
  });
  $$('.nav-link').forEach(link => link.addEventListener('click', () => {
    $$('.nav-link').forEach(item => item.classList.toggle('active', item === link));
    $('#mainNav').classList.remove('open');
    $('#menuToggle').setAttribute('aria-expanded', 'false');
  }));

  // Map / satellite presentation switch (same reference map, alternate visual treatment)
  $$('.map-tab').forEach(tab => tab.addEventListener('click', () => {
    $$('.map-tab').forEach(item => item.classList.toggle('selected', item === tab));
    const satellite = tab.dataset.mode === 'satellite';
    mapPanel.classList.toggle('satellite', satellite);
    showMapToast(satellite ? 'Satellite-style view selected' : 'Map view selected');
  }));
  $('#zoomIn').addEventListener('click', () => setZoom(zoom + .15));
  $('#zoomOut').addEventListener('click', () => setZoom(zoom - .15));
  $('#resetMap').addEventListener('click', () => {
    zoom = 1; panX = 0; panY = 0; applyMapTransform();
    mapPanel.classList.remove('satellite');
    $$('.map-tab').forEach(tab => tab.classList.toggle('selected', tab.dataset.mode === 'map'));
    $$('.map-hotspot').forEach(marker => marker.classList.remove('filtered-out', 'active'));
    $$('.category-item').forEach(button => { button.classList.remove('selected'); button.setAttribute('aria-pressed','false'); });
    showMapToast('Map view reset');
  });

  // Drag/pan the reference map on desktop and touch devices
  let drag = null;
  mapPanel.addEventListener('pointerdown', event => {
    if (event.target.closest('button, a')) return;
    drag = { x:event.clientX, y:event.clientY, startX:panX, startY:panY };
    mapPanel.classList.add('dragging');
    mapPanel.setPointerCapture(event.pointerId);
  });
  mapPanel.addEventListener('pointermove', event => {
    if (!drag) return;
    panX = drag.startX + event.clientX - drag.x;
    panY = drag.startY + event.clientY - drag.y;
    applyMapTransform();
  });
  function endDrag() { drag = null; mapPanel.classList.remove('dragging'); }
  mapPanel.addEventListener('pointerup', endDrag);
  mapPanel.addEventListener('pointercancel', endDrag);

  // Category controls
  $$('.category-item').forEach(button => button.addEventListener('click', () => selectCategory(button.dataset.category)));

  // Search locations, barangays and attractions
  $('#searchForm').addEventListener('submit', event => {
    event.preventDefault();
    const input = $('#locationSearch');
    const query = input.value.trim().toLowerCase();
    if (!query) { showNotice('Please enter a barangay or tourist destination.'); input.focus(); return; }
    const match = places.find(place => place.name.toLowerCase().includes(query) || query.includes(place.name.toLowerCase()));
    if (match) {
      $$('.map-hotspot').forEach(marker => marker.classList.remove('filtered-out'));
      $$('.category-item').forEach(button => { button.classList.toggle('selected', button.dataset.category === match.category); button.setAttribute('aria-pressed',String(button.dataset.category === match.category)); });
      openPlace(match);
      $('#map').scrollIntoView({ behavior:'smooth', block:'center' });
      showNotice(`Location found: ${match.name}`);
      return;
    }
    const category = ['barangay','beach','mountain','river','fall','tourist','hall'].find(term => query.includes(term));
    if (category) {
      const mapCategory = category === 'barangay' ? 'Barangays' : category === 'beach' ? 'Beaches' : category === 'mountain' ? 'Mountains' : (category === 'river' || category === 'fall') ? 'Rivers & Falls' : category === 'hall' ? 'Municipal Hall' : 'Tourist Spots';
      selectCategory(mapCategory); showNotice(`Showing ${mapCategory}`); return;
    }
    showNotice(`No matching location found for “${input.value.trim()}”. Try Poblacion, Cabangan Beach, or San Felipe Falls.`);
  });

  // Attraction cards open their own details rather than navigating to an empty section
  $$('.attraction').forEach(item => item.addEventListener('click', event => {
    event.preventDefault();
    const place = places.find(entry => entry.name === item.dataset.search);
    if (place) openPlace(place);
    else openModal(item.dataset.search, 'Tourism information for this destination can be added by the website administrator.', $('img', item)?.src);
  }));
  const newsLink = $('.news-heading a');
  if (newsLink) newsLink.addEventListener('click', event => {
    event.preventDefault();
    openModal('News & Updates', 'Botolan LGU launches new tourism program! This sample news item follows the reference design. Replace this text with verified announcements and current municipal updates.', 'assets/municipal-hall.png');
  });
  $$('.footer-feature, .explore-button').forEach(link => link.addEventListener('click', () => {
    if (link.getAttribute('href') === 'mailto:tourism@botolan.gov.ph') return;
    const target = $(link.getAttribute('href'));
    if (target) target.scrollIntoView({ behavior:'smooth', block:'start' });
  }));

  // Dialog controls
  $('#modalClose').addEventListener('click', closeModal);
  $('#infoModal').addEventListener('click', event => { if (event.target === $('#infoModal')) closeModal(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });

  renderMarkers();
})();
